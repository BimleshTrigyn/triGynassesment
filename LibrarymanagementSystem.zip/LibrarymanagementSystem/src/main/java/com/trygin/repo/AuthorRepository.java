package com.trygin.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.trygin.entity.Author;

public interface AuthorRepository extends JpaRepository<Author, Long> {

}
